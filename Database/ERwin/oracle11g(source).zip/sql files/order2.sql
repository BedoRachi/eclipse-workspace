insert into orders 
(id, product_code, product_size, quantity)
values('one', 'sp0001', '235', '3');

insert into orders 
(id, product_code, product_size, quantity)
values('two', 'sp0001', '230', '1');

insert into orders 
(id, product_code, product_size, quantity)
values('two', 'bt0001', '235', '1');

insert into orders 
(id, product_code, product_size, quantity)
values('two', 'sa0001', '235', '2');

insert into orders 
(id, product_code, product_size, quantity)
values('two', 'hi0001', '235', '2');